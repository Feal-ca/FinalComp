#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

void Usage(char * param){
	printf("This program needs integer number/s as input parameter/s. It will write binary format.\n");
}
	
int main(int argc, char **argv){
	int i;
	int num;
	
	if (argc == 1){
		Usage(argv[0]);
		return 1;
	}
	for (i=2; i<argc; i++){
		if (strcmp(argv[1], "int")){
			num = (int) atoi(argv[i]);
			write(1, &num, sizeof(int));
		}
		else if (strcmp(argv[1], "char")){
			num = (int) atoi(argv[i]);
			write(1, &num, sizeof(char));
		}
		else if (strcmp(argv[1], "short")){
			num = (int) atoi(argv[i]);
			write(1, &num, sizeof(short));
		}
		else if (strcmp(argv[1], "long")){
			num = (long) atol(argv[i]);
			write(1, &num, sizeof(long));
		}
		else if (strcmp(argv[1], "longlong")){
			num = (long long) atoll(argv[i]);
			write(1, &num, sizeof(long long));
		}

	}
	return 0;	
}
